package servlets;

import dao.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.*;
import javax.servlet.http.*;

public class AddFacultyServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            int deptId = Integer.parseInt(request.getParameter("department_id"));
            String subject = request.getParameter("subject");
            int experience = Integer.parseInt(request.getParameter("experience"));
            double salary = Double.parseDouble(request.getParameter("salary"));

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO faculty(name,email,phone,department_id,subject,experience,salary) VALUES(?,?,?,?,?,?,?)"
            );

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setInt(4, deptId);
            ps.setString(5, subject);
            ps.setInt(6, experience);
            ps.setDouble(7, salary);

            int result = ps.executeUpdate();

            if (result > 0) {
                // Redirect with success parameter
                response.sendRedirect("viewFaculty.jsp?added=success");
            } else {
                response.sendRedirect("addFaculty.jsp?added=fail");
            }
            return;

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("addFaculty.jsp?added=fail");
            return;
        }
    }
}