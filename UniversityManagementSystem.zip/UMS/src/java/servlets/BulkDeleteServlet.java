package servlets;

import dao.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.*;
import javax.servlet.http.*;

public class BulkDeleteServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String[] ids = request.getParameterValues("studentIds");
        
        if (ids != null && ids.length > 0) {
            try (Connection con = DBConnection.getConnection()) {
                // Construct query: DELETE FROM students WHERE id IN (1, 2, 3...)
                StringBuilder sql = new StringBuilder("DELETE FROM students WHERE id IN (");
                for (int i = 0; i < ids.length; i++) {
                    sql.append("?");
                    if (i < ids.length - 1) sql.append(",");
                }
                sql.append(")");

                PreparedStatement ps = con.prepareStatement(sql.toString());
                for (int i = 0; i < ids.length; i++) {
                    ps.setInt(i + 1, Integer.parseInt(ids[i]));
                }

                int result = ps.executeUpdate();
                response.sendRedirect("viewStudents.jsp?deleted=success");
                
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("viewStudents.jsp?deleted=fail");
            }
        } else {
            response.sendRedirect("viewStudents.jsp");
        }
    }
}