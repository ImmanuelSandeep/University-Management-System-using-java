package servlets;

import dao.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.*;
import javax.servlet.http.*;

public class UpdateFacultyServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String subject = request.getParameter("subject");
        String departmentId = request.getParameter("department_id");

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "UPDATE faculty SET name=?, email=?, phone=?, subject=?, experience=?, salary=?, department_id=? WHERE id=?"
            );

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setString(4, subject);
            ps.setInt(5, Integer.parseInt(request.getParameter("experience")));
            ps.setInt(6, Integer.parseInt(request.getParameter("salary")));
            ps.setInt(7, Integer.parseInt(departmentId));
            ps.setInt(8, id);

            ps.executeUpdate();
            int result = ps.executeUpdate();
            if (result > 0) {
                response.sendRedirect("viewFaculty.jsp?updated=success");
            } else {
                response.sendRedirect("viewFaculty.jsp?updated=fail");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("viewFaculty.jsp?updated=fail");
        }
    }
}
