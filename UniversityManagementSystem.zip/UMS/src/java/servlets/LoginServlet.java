package servlets;

import dao.DBConnection;
import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "SELECT * FROM users WHERE username=? AND password=?"
            );
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // ✅ Get or create the session object
                HttpSession session = request.getSession();

                session.setAttribute("user", username);
                session.setAttribute("role", rs.getString("role"));
                PreparedStatement logPs = con.prepareStatement(
                        "INSERT INTO login_logs(username, role) VALUES(?,?)"
                );

                logPs.setString(1, username);
                logPs.setString(2, rs.getString("role"));
                logPs.executeUpdate();

                response.sendRedirect("dashboard.jsp");
            } else {
                response.sendRedirect("login.jsp?error=1");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
