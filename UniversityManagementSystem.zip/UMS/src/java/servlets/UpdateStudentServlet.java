package servlets;

import dao.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.*;
import javax.servlet.http.*;

public class UpdateStudentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Connection con = null;
        PreparedStatement ps = null;

        try {
            // 1. Get Parameters
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            int deptId = Integer.parseInt(request.getParameter("department_id"));
            int year = Integer.parseInt(request.getParameter("year"));

            // 2. Database Operation
            con = DBConnection.getConnection();
            String sql = "UPDATE students SET name=?, email=?, phone=?, department_id=?, year=? WHERE id=?";
            ps = con.prepareStatement(sql);

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setInt(4, deptId);
            ps.setInt(5, year);
            ps.setInt(6, id);

            int rowsUpdated = ps.executeUpdate();

            // 3. Redirect with Status
            if (rowsUpdated > 0) {
                response.sendRedirect("viewStudents.jsp?updated=success");
                return;
            } else {
                // If no rows were updated, something went wrong (e.g., ID not found)
                response.sendRedirect("editStudent.jsp?id=" + id + "&updated=fail");
                return;
            }

        } catch (Exception e) {
            e.printStackTrace();
            // Try to redirect back to edit page if we have the ID, otherwise view page
            String studentId = request.getParameter("id");
            if (studentId != null) {
                response.sendRedirect("editStudent.jsp?id=" + studentId + "&updated=fail");
            } else {
                response.sendRedirect("viewStudents.jsp?updated=fail");
            }
            return;
        } finally {
            try {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}