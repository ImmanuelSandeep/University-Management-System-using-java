package servlets;

import dao.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.*;
import javax.servlet.http.*;

public class DeleteStudentServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            Connection con = DBConnection.getConnection();
            String id = request.getParameter("id");
            PreparedStatement ps = con.prepareStatement("DELETE FROM students WHERE id = ?");
            ps.setString(1, id);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                // Use return to stop execution here!
                response.sendRedirect("viewStudents.jsp?deleted=success");
                return;
            } else {
                response.sendRedirect("viewStudents.jsp?deleted=fail");
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("viewStudents.jsp?deleted=fail");
        }
    }
}
