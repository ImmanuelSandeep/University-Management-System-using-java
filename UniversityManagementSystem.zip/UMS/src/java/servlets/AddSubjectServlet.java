package servlets;

import dao.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.*;
import javax.servlet.http.*;

public class AddSubjectServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        int deptId = Integer.parseInt(request.getParameter("department_id"));
        int credits = Integer.parseInt(request.getParameter("credits"));

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
            "INSERT INTO subjects(name,department_id,credits) VALUES(?,?,?)"
            );

            ps.setString(1, name);
            ps.setInt(2, deptId);
            ps.setInt(3, credits);

            ps.executeUpdate();

            response.sendRedirect("viewSubjects.jsp");

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}