package servlets;

import dao.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.*;
import javax.servlet.http.*;

public class AddFeesServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int studentId = Integer.parseInt(request.getParameter("student_id"));
        double amount = Double.parseDouble(request.getParameter("amount"));
        String status = request.getParameter("status");
        int semester = Integer.parseInt(request.getParameter("semester"));

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO fees(student_id,amount,semester,status) VALUES(?,?,?,?)"
            );

            ps.setInt(1, studentId);
            ps.setDouble(2, amount);
            ps.setInt(3, semester);
            ps.setString(4, status);

            ps.executeUpdate();

            response.sendRedirect("viewFees.jsp");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
