package servlets;

import dao.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.*;
import javax.servlet.http.*;

public class DeleteFacultyServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Use a try-with-resources or finally block to close connections!
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM faculty WHERE id=?"
            );

            ps.setInt(1, id);
            
            // Execute ONLY ONCE and capture the result
            int result = ps.executeUpdate(); 

            if (result > 0) {
                response.sendRedirect("viewFaculty.jsp?deleted=success");
            } else {
                response.sendRedirect("viewFaculty.jsp?deleted=fail");
            }
            return; // Good practice to stop execution here

        } catch (Exception e) {
            e.printStackTrace();
            // If an actual crash happens, redirect to fail
            response.sendRedirect("viewFaculty.jsp?deleted=fail");
        }
    }
}