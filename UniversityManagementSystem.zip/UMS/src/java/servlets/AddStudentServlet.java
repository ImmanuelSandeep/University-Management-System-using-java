package servlets;

import dao.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.*;
import javax.servlet.http.*;

public class AddStudentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Initialize variables outside try to handle scope
        Connection con = null;
        PreparedStatement ps = null;

        try {
            // 2. Extract parameters from the form
            String rollno = request.getParameter("rollno");
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");

            // Handle potential parsing errors for numbers
            int deptId = Integer.parseInt(request.getParameter("department_id"));
            int year = Integer.parseInt(request.getParameter("year"));

            // 3. Establish Database Connection
            con = DBConnection.getConnection();
            PreparedStatement check = con.prepareStatement(
                    "SELECT * FROM students WHERE rollno=?"
            );

            check.setString(1, rollno);
            ResultSet rs = check.executeQuery();

            if (rs.next()) {
                response.sendRedirect("addStudent.jsp?error=duplicate");
                return;
            }
            // 4. Prepare the SQL Statement
            String sql = "INSERT INTO students(rollno, name, email, phone, department_id, year) VALUES(?,?,?,?,?,?)";
            ps = con.prepareStatement(sql);

            ps.setString(1, rollno);
            ps.setString(2, name);
            ps.setString(3, email);
            ps.setString(4, phone);
            ps.setInt(5, deptId);
            ps.setInt(6, year);

            // 5. Execute and check result
            int rowsInserted = ps.executeUpdate();

            if (rowsInserted > 0) {
                // SUCCESS: Redirect to the list view
                response.sendRedirect("viewStudents.jsp?added=success");
                return; // Stop further execution
            } else {
                // FAIL: Redirect back to the entry form
                response.sendRedirect("addStudent.jsp?added=fail");
                return;
            }

        } catch (Exception e) {
            e.printStackTrace();
            // ERROR: Redirect back to form with fail status
            response.sendRedirect("addStudent.jsp?added=fail");
            return;
        } finally {
            // 6. Resource Cleanup
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
