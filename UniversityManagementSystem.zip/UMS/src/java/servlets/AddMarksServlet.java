package servlets;

import dao.DBConnection;
import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AddMarksServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int studentId = Integer.parseInt(request.getParameter("student_id"));
        int subjectId = Integer.parseInt(request.getParameter("subject_id"));

        int ct = Integer.parseInt(request.getParameter("class_test"));
        int ses = Integer.parseInt(request.getParameter("sessional"));
        int finalExam = Integer.parseInt(request.getParameter("final_exam"));

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
            "INSERT INTO marks(student_id,subject_id,class_test,sessional,final_exam) VALUES(?,?,?,?,?)"
            );

            ps.setInt(1, studentId);
            ps.setInt(2, subjectId);
            ps.setInt(3, ct);
            ps.setInt(4, ses);
            ps.setInt(5, finalExam);

            ps.executeUpdate();

            // 🔥 CALCULATE SGPA
            calculateSGPA(studentId, con);

            response.sendRedirect("viewResults.jsp");

        } catch(Exception e){
            e.printStackTrace();
        }
    }

    private void calculateSGPA(int studentId, Connection con) throws Exception {

        PreparedStatement ps = con.prepareStatement(
        "SELECT m.*, s.credits FROM marks m JOIN subjects s ON m.subject_id=s.id WHERE student_id=?"
        );

        ps.setInt(1, studentId);

        ResultSet rs = ps.executeQuery();

        double totalPoints = 0;
        double totalCredits = 0;

        while(rs.next()){
            int total = rs.getInt("class_test") + rs.getInt("sessional") + rs.getInt("final_exam");
            int credits = rs.getInt("credits");

            double gradePoint = total / 10.0; // simple logic

            totalPoints += gradePoint * credits;
            totalCredits += credits;
        }

        double sgpa = totalPoints / totalCredits;

        PreparedStatement ps2 = con.prepareStatement(
        "REPLACE INTO results(student_id,sgpa,cgpa) VALUES(?,?,?)"
        );

        ps2.setInt(1, studentId);
        ps2.setDouble(2, sgpa);
        ps2.setDouble(3, sgpa);

        ps2.executeUpdate();
    }
}