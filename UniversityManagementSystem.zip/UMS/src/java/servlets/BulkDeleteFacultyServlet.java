package servlets;

import dao.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.*;
import javax.servlet.http.*;

public class BulkDeleteFacultyServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String[] ids = request.getParameterValues("facultyIds");
        
        if (ids != null && ids.length > 0) {
            try (Connection con = DBConnection.getConnection()) {
                // Build a dynamic query like: DELETE FROM faculty WHERE id IN (?, ?, ?)
                StringBuilder sql = new StringBuilder("DELETE FROM faculty WHERE id IN (");
                for (int i = 0; i < ids.length; i++) {
                    sql.append("?");
                    if (i < ids.length - 1) sql.append(",");
                }
                sql.append(")");

                PreparedStatement ps = con.prepareStatement(sql.toString());
                for (int i = 0; i < ids.length; i++) {
                    ps.setInt(i + 1, Integer.parseInt(ids[i]));
                }

                ps.executeUpdate();
                response.sendRedirect("viewFaculty.jsp?deleted=success");
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("viewFaculty.jsp?deleted=fail");
            }
        } else {
            response.sendRedirect("viewFaculty.jsp");
        }
    }
}