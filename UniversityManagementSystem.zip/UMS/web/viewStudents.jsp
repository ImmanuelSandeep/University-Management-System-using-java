<%@ page import="java.sql.*, dao.DBConnection" %>
<%
    String role = (String) session.getAttribute("role");
    if (!role.equals("admin") && !role.equals("adminstaff")) {
        response.sendRedirect("accessDenied.jsp");
    }

    if (session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
    }
    // --- PAGINATION LOGIC ---
    int rowsPerPage = 50; // Change this to 20 or 50 if you prefer
    int currentPage = 1;
    if (request.getParameter("page") != null) {
        currentPage = Integer.parseInt(request.getParameter("page"));
    }
    int offset = (currentPage - 1) * rowsPerPage;

    Connection con = dao.DBConnection.getConnection();

    String Branch = request.getParameter("Branch");
    String year = request.getParameter("year");

    // 1. Build Base Query
    String query = "SELECT s.*, d.name AS dept_name FROM students s "
            + "JOIN departments d ON s.department_id = d.id WHERE 1=1";

    // 2. Add Filters
    if (Branch != null && !Branch.equals("")) {
        query += " AND d.name='" + Branch + "'";
    }
    if (year != null && !year.equals("")) {
        query += " AND s.year=" + year;
    }

    // 3. Add Ordering and LIMIT/OFFSET
    query += " ORDER BY s.id ASC LIMIT " + rowsPerPage + " OFFSET " + offset;

    PreparedStatement ps = con.prepareStatement(query);
    ResultSet rs = ps.executeQuery();
%>


<!DOCTYPE html>
<html>
    <head>
        <title>View Students</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    </head>
    <%@ include file="navbar.jsp" %>

    <div class="d-flex">
        <%@ include file="sidebar.jsp" %>

        <div style="margin-left:100px; padding:20px; width:100%;">

            <h3>Students</h3>
            <%
                String added = request.getParameter("added");
                String deleted = request.getParameter("deleted");
                String updated = request.getParameter("updated");
            %>

            <% if ("success".equals(added)) { %>
            <div class="alert alert-success alert-dismissible fade show">
                Student added successfully!
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <% } else if ("failed".equals(added)) { %>
            <div class="alert alert-danger">Failed to add student!</div>
            <% } %>

            <% if ("success".equals(deleted)) { %>
            <div class="alert alert-success alert-dismissible fade show">
                Student deleted successfully!
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <% } %>

            <% if ("success".equals(updated)) { %>
            <div class="alert alert-success alert-dismissible fade show">
                Student updated successfully!
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <% } %>

            <!-- FILTER FORM -->
            <form method="get" class="mb-3 d-flex align-items-center">

                <!-- Department filter -->
                <select name="Branch" class="form-select w-25 me-2">
                    <option value="">All Departments</option>
                    <%
                        Connection conDept = DBConnection.getConnection();
                        PreparedStatement psDept = conDept.prepareStatement("SELECT * FROM departments");
                        ResultSet rsDept = psDept.executeQuery();
                        while (rsDept.next()) {
                            String deptName = rsDept.getString("name");
                    %>
                    <option value="<%= deptName%>"><%= deptName%></option>
                    <%
                        }
                        rsDept.close();
                        psDept.close();
                        conDept.close();
                    %>
                </select>

                <!-- Year filter -->
                <select name="year" class="form-select w-25 me-2">
                    <option value="">All Years</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                </select>

                <!-- Filter button -->
                <button class="btn btn-primary me-2">Filter</button>

                <!-- Add Student button aligned right -->
                <div class="ms-auto" id="actionButtonContainer">
                    <a href="addStudent.jsp" id="addBtn" class="btn btn-success">Add Student</a>
                    <button type="button" id="deleteSelectedBtn" class="btn btn-danger" style="display: none;" onclick="submitBulkDelete()">
                        Delete Selected (<span id="count">0</span>)
                    </button>
                </div>
            </form>
            <form id="bulkDeleteForm" action="BulkDeleteServlet" method="post">
                <table class="table table-bordered">
                    <tr>
                        <th><input type="checkbox" id="selectAll"></th> <th>ID</th>
                        <th>Roll No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Department</th>
                        <th>Year</th>
                        <th>Actions</th>
                    </tr>

                    <% while (rs.next()) {%>
                    <tr>
                        <td>
                            <input type="checkbox" name="studentIds" value="<%= rs.getInt("id")%>" class="student-checkbox">
                        </td>
                        <td><%= rs.getInt("id")%></td>
                        <td><%= rs.getString("rollno")%></td>
                        <td><%= rs.getString("name")%></td>
                        <td><%= rs.getString("email")%></td>
                        <td><%= rs.getString("dept_name")%></td>
                        <td><%= rs.getInt("year")%></td>
                        <td>
                            <a href="editStudent.jsp?id=<%= rs.getInt("id")%>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="DeleteStudentServlet?id=<%= rs.getInt("id")%>" 
                               class="btn btn-danger btn-sm" 
                               onclick="return confirm('Delete this student?')">Delete</a>
                        </td>
                    </tr>
                    <% }%>
                </table>
            </form>
            <nav aria-label="Page navigation" class="mt-4">
                <ul class="pagination justify-content-center">

                    <li class="page-item <%= (currentPage == 1) ? "disabled" : ""%>">
                        <a class="page-link" href="?page=<%= currentPage - 1%>&Branch=<%= (Branch != null) ? Branch : ""%>&year=<%= (year != null) ? year : ""%>">
                            &laquo; Previous
                        </a>
                    </li>

                    <li class="page-item disabled">
                        <span class="page-link text-dark">
                            Page <strong><%= currentPage%></strong>
                        </span>
                    </li>

                    <li class="page-item">
                        <a class="page-link" href="?page=<%= currentPage + 1%>&Branch=<%= (Branch != null) ? Branch : ""%>&year=<%= (year != null) ? year : ""%>">
                            Next &raquo;
                        </a>
                    </li>

                </ul>
            </nav>

        </div>
    </div>

    <%@ include file="footer.jsp" %>
    <script>


        document.addEventListener("DOMContentLoaded", function () {
            const selectAll = document.getElementById('selectAll');
            const checkboxes = document.querySelectorAll('.student-checkbox');
            const addBtn = document.getElementById('addBtn');
            const deleteSelectedBtn = document.getElementById('deleteSelectedBtn');
            const countSpan = document.getElementById('count');

            function updateDeleteUI() {
                // Find all checkboxes that are currently checked
                const checkedBoxes = document.querySelectorAll('.student-checkbox:checked');
                const checkedCount = checkedBoxes.length;

                if (checkedCount) {
                    // Hide Add, Show Delete
                    addBtn.style.setProperty('display', 'none', 'important');
                    deleteSelectedBtn.style.setProperty('display', 'block', 'important');
                    countSpan.textContent = checkedCount;
                } else {
                    // Show Add, Hide Delete
                    addBtn.style.setProperty('display', 'block', 'important');
                    deleteSelectedBtn.style.setProperty('display', 'none', 'important');
                }
            }

            // 1. Individual Checkboxes
            checkboxes.forEach(cb => {
                cb.addEventListener('change', updateDeleteUI);
            });

            // 2. Select All Checkbox
            if (selectAll) {
                selectAll.addEventListener('change', function () {
                    checkboxes.forEach(cb => {
                        cb.checked = this.checked;
                    });
                    updateDeleteUI();
                });
            }
        });

// Function outside listener so button can call it
        function submitBulkDelete() {
            if (confirm("Are you sure you want to delete the selected students?")) {
                document.getElementById('bulkDeleteForm').submit();
            }
        }
    </script>
</body>
</html>