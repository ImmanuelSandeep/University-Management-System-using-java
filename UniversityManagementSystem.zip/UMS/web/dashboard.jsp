<%@ page session="true" %>
<%
    String role = (String) session.getAttribute("role");

    if (role == null) {
        response.sendRedirect("login.jsp");
    }
%>
<%@ page import="java.sql.*, dao.DBConnection" %>

<%
    Connection con = DBConnection.getConnection();

    int students = 0, faculty = 0, subjects = 0, defaulters = 0;
    double totalFees = 0, highestDue = 0, topperCGPA = 0;
    String topperName = "-";

// TOTAL STUDENTS
    ResultSet rs1 = con.createStatement().executeQuery("SELECT COUNT(*) FROM students");
    if (rs1.next()) {
        students = rs1.getInt(1);
    }

// TOTAL FACULTY
    ResultSet rs2 = con.createStatement().executeQuery("SELECT COUNT(*) FROM faculty");
    if (rs2.next()) {
        faculty = rs2.getInt(1);
    }

// TOTAL SUBJECTS
    ResultSet rs3 = con.createStatement().executeQuery("SELECT COUNT(*) FROM subjects");
    if (rs3.next()) {
        subjects = rs3.getInt(1);
    }

// TOTAL FEES COLLECTED
    ResultSet rs4 = con.createStatement().executeQuery("SELECT SUM(amount) FROM fees WHERE status='Paid'");
    if (rs4.next()) {
        totalFees = rs4.getDouble(1);
    }

// DEFAULTERS COUNT
    ResultSet rs5 = con.createStatement().executeQuery("SELECT COUNT(*) FROM fees WHERE status='Unpaid'");
    if (rs5.next()) {
        defaulters = rs5.getInt(1);
    }

// HIGHEST DUE
    ResultSet rs6 = con.createStatement().executeQuery("SELECT MAX(amount) FROM fees WHERE status='Unpaid'");
    if (rs6.next()) {
        highestDue = rs6.getDouble(1);
    }

// TOPPER
    ResultSet rs7 = con.createStatement().executeQuery(
            "SELECT s.name, r.cgpa FROM results r JOIN students s ON r.student_id=s.id ORDER BY r.cgpa DESC LIMIT 1"
    );

    if (rs7.next()) {
        topperName = rs7.getString("name");
        topperCGPA = rs7.getDouble("cgpa");
    }
    PreparedStatement branchPs = con.prepareStatement(
            "SELECT d.name AS dept, s.name, r.cgpa "
            + "FROM results r "
            + "JOIN students s ON r.student_id = s.id "
            + "JOIN departments d ON s.department_id = d.id "
            + "WHERE (d.id, r.cgpa) IN ( "
            + "   SELECT s2.department_id, MAX(r2.cgpa) "
            + "   FROM results r2 "
            + "   JOIN students s2 ON r2.student_id = s2.id "
            + "   GROUP BY s2.department_id "
            + ") "
            + "ORDER BY dept"
    );

    ResultSet branchRs = branchPs.executeQuery();
%>
<!DOCTYPE html>
<html>
    <head>
        <title>Dashboard</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <style>
            body {
                background: linear-gradient(135deg, #eef2f7, #f8fafc);
                font-family: 'Segoe UI', sans-serif;
            }

            /* CARD BASE */
            .card-modern {
                border-radius: 16px;
                padding: 20px;
                background: rgba(255, 255, 255, 0.75);
                backdrop-filter: blur(10px);
                box-shadow: 0 8px 25px rgba(0,0,0,0.08);
                transition: all 0.3s ease;
                height: 140px;
                display: flex;
                flex-direction: column;
                justify-content: center;
            }

            .card-modern:hover {
                transform: translateY(-6px);
                box-shadow: 0 12px 35px rgba(0,0,0,0.15);
            }

            /* TEXT */
            .card-title {
                font-size: 14px;
                color: #6c757d;
            }

            .card-value {
                font-size: 30px;
                font-weight: bold;
                color: #111;
            }

            /* SECTION TITLE */
            .section-title {
                margin-top: 25px;
                margin-bottom: 10px;
                font-weight: 600;
                color: #333;
            }

            /* COLOR ACCENTS */
            .blue { border-left: 5px solid #3b82f6; }
            .green { border-left: 5px solid #22c55e; }
            .yellow { border-left: 5px solid #f59e0b; }
            .red { border-left: 5px solid #ef4444; }
            .purple { border-left: 5px solid #8b5cf6; }
            .gray { border-left: 5px solid #6b7280; }

            /* TOPPER CARD */
            .highlight-card {
                border-radius: 16px;
                padding: 20px;
                background: linear-gradient(135deg, #6366f1, #8b5cf6);
                color: white;
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            }

            .highlight-card h4 {
                margin: 0;
            }

            .branch-card {
                border-radius: 12px;
                padding: 15px;
                margin-bottom: 15px;
                background: #fff;
                box-shadow: 0 5px 15px rgba(0,0,0,0.08);
                height: 150px;
            }

            .row {
                display: flex;
                flex-wrap: wrap;
            }
        </style>
    </head>
    <%@ include file="navbar.jsp" %>

    <div class="d-flex">
        <%@ include file="sidebar.jsp" %>        

        <div style="margin-left:120px; padding:20px; width:100%;">

            <h2>Dashboard</h2>

            <!-- ================= ACADEMIC OVERVIEW ================= -->
            <h5 class="section-title">Academic Overview</h5>

            <div class="row">

                <div class="col-md-4">
                    <div class="card-modern blue animate__animated animate__fadeInUp" onclick="goTo('viewStudents.jsp')">
                        <div class="card-title">Total Students</div>
                        <div class="card-value"><%= students%></div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card-modern green animate__animated animate__fadeInUp" onclick="goTo('viewFaculty.jsp')">
                        <div class="card-title">Total Faculty</div>
                        <div class="card-value"><%= faculty%></div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card-modern purple animate__animated animate__fadeInUp" onclick="goTo('viewSubjects.jsp')">
                        <div class="card-title">Total Subjects</div>
                        <div class="card-value"><%= subjects%></div>
                    </div>
                </div>

            </div>

            <!-- ================= FINANCIAL ================= -->
            <h5 class="section-title">Financial Overview</h5>

            <div class="row">

                <div class="col-md-4">
                    <div class="card-modern green animate__animated animate__fadeInUp" onclick="goTo('viewFees.jsp')">
                        <div class="card-title">Total Fees</div>
                        <div class="card-value"><%= totalFees%></div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card-modern red animate__animated animate__fadeInUp"onclick="goTo('viewFees.jsp')">
                        <div class="card-title">Defaulters</div>
                        <div class="card-value"><%= defaulters%></div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card-modern yellow animate__animated animate__fadeInUp" onclick="goTo('viewFees.jsp')">
                        <div class="card-title">Highest Due</div>
                        <div class="card-value"><%= highestDue%></div>
                    </div>
                </div>

            </div>

            <!-- ================= PERFORMANCE ================= -->
            <h5 class="section-title">Top Performer</h5>

            <div class="row">

                <div class="col-md-6">
                    <div class="highlight-card animate__animated animate__fadeInUp" onclick="goTo('viewResults.jsp')">

                        <h6>Overall Topper</h6>
                        <h4><%= topperName%></h4>
                        <p>CGPA: <strong><%= topperCGPA%></strong></p>

                    </div>
                </div>

            </div>
            <h5 class="section-title">Branch-wise Toppers</h5>

            <div class="row">

                <%
                    while (branchRs.next()) {
                %>

                <div class="col-md-3 mb-3">
                    <div class="card-modern gray text-center animate__animated animate__fadeInUp" onclick="goTo('viewResults.jsp')">

                        <div class="card-title"><%= branchRs.getString("dept")%></div>
                        <div class="card-value" style="font-size:18px;">
                            <%= branchRs.getString("name")%>
                        </div>
                        <p>CGPA: <%= branchRs.getDouble("cgpa")%></p>

                    </div>
                </div>

                <%
                    }
                %>

            </div>
        </div>

    </div>
    <%@ include file="footer.jsp" %>
    <script>
        function goTo(page) {
            window.location.href = page;
        }
        const feeChart = new Chart(document.getElementById('feeChart'), {
            type: 'bar',
            data: {
                labels: ['Collected', 'Unpaid'],
                datasets: [{
                        label: 'Fees',
                        data: [<%= totalFees%>, <%= highestDue%>],
                    }]
            }
        });

        const studentChart = new Chart(document.getElementById('studentChart'), {
            type: 'doughnut',
            data: {
                labels: ['Students', 'Faculty'],
                datasets: [{
                        data: [<%= students%>, <%= faculty%>],
                    }]
            }
        });
    </script>
</html>