<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
<nav class="navbar navbar-expand-lg bg-white shadow-sm px-3">

<h5 class="mb-0">University Management System</h5>

<div class="ms-auto d-flex align-items-center">

<span class="me-3">Loggined As
<%= session.getAttribute("user") %>
</span>

<button onclick="toggleDark()" class="btn btn-sm btn-outline-dark me-2">Mode</button>

<a href="LogoutServlet" class="btn btn-danger btn-sm">Logout</a>

</div>

</nav>
<style>
    .dark-mode {
        background: #121212 !important;
        color: white !important;
    }

    .dark-mode .card-modern {
        background: #1e1e1e;
        color: white;
    }
</style>
<script>
function toggleDark() {
    document.body.classList.toggle("dark-mode");
}
</script>