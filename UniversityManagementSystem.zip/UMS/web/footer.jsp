<footer class="mt-4 text-center p-3" style="background:#111827; color:white;">

<h5>University Management System</h5>

<p class="mb-1">
Developed by: P. Immanuel Sandeep , M. R. V. Tarun, D. Mahesh Babu, P. Nireekshan Pal
</p>

<p class="mb-0">
� 2026 All Rights Reserved
</p>

</footer>