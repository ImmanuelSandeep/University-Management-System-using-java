<%@ page import="java.sql.*, dao.DBConnection" %>
<%@ include file="navbar.jsp" %>
<%
    String role = (String) session.getAttribute("role");

    if (!role.equals("admin") && !role.equals("finance")) {
        response.sendRedirect("accessDenied.jsp");
    }
%>
<!DOCTYPE html>
<html>
    <head>
        <title>View Students</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    </head>
    <body>
        <div class="d-flex">
            <%@ include file="sidebar.jsp" %>

            <div style="margin-left:100px; padding:20px; width:100%;">

                <h3>Fees Management</h3>

                <%
                    String dept = request.getParameter("dept");
                    String year = request.getParameter("year");
                    String status = request.getParameter("status");

                    Connection con = DBConnection.getConnection();

                    String query = "SELECT f.*, s.name, s.year, d.name AS dept "
                            + "FROM fees f "
                            + "JOIN students s ON f.student_id=s.id "
                            + "JOIN departments d ON s.department_id=d.id WHERE 1=1";

                    if (dept != null && !dept.equals("")) {
                        query += " AND d.name='" + dept + "'";
                    }

                    if (year != null && !year.equals("")) {
                        query += " AND s.year=" + year;
                    }

                    if (status != null && !status.equals("")) {
                        query += " AND f.status='" + status + "'";
                    }

                    PreparedStatement ps = con.prepareStatement(query);
                    ResultSet rs = ps.executeQuery();
                %>

                <!-- Filter Form -->
                <form method="get" class="mb-3">
                    <!-- DEPARTMENT -->
                    <select name="dept" class="form-select w-25 d-inline">
                        <option value="">All Departments</option>
                        <%
                            Connection con2 = DBConnection.getConnection();
                            Statement st2 = con2.createStatement();
                            ResultSet rs2 = st2.executeQuery("SELECT * FROM departments");
                            while (rs2.next()) {
                        %>
                        <option value="<%= rs2.getString("name")%>">
                            <%= rs2.getString("name")%>
                        </option>
                        <% } %>
                    </select>

                    <!-- YEAR -->
                    <select name="year" class="form-select w-25 d-inline">
                        <option value="">All Years</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                    </select>

                    <!-- STATUS -->
                    <select name="status" class="form-select w-25 d-inline">
                        <option value="">All</option>
                        <option value="Paid">Paid</option>
                        <option value="Unpaid">Unpaid</option>
                    </select>

                    <button class="btn btn-primary">Filter</button>
                </form>

                <%
                    PreparedStatement totalPs = con.prepareStatement(
                            "SELECT SUM(amount) FROM fees WHERE status='Paid'"
                    );
                    ResultSet totalRs = totalPs.executeQuery();
                    totalRs.next();
                %>

                <h5>Total Collected: <%= totalRs.getDouble(1)%></h5>

                <!-- Fees Table -->
                <table class="table table-bordered">
                    <tr>
                        <th>Student</th>
                        <th>Department</th>
                        <th>Year / Semester</th>
                        <th>Amount</th>
                        <th>Status</th>
                    </tr>

                    <%
                        while (rs.next()) {
                    %>
                    <tr>
                        <td><%= rs.getString("name")%></td>
                        <td><%= rs.getString("dept")%></td>
                        <td>
                            Year <%= rs.getInt("year")%> 
                            (Sem <%= (rs.getInt("year") * 2 - 1)%>-<%= (rs.getInt("year") * 2)%>)
                        </td>
                        <td><%= rs.getDouble("amount")%></td>
                        <td>
                            <% if ("Paid".equals(rs.getString("status"))) { %>
                            <span class="badge bg-success">Paid</span>
                            <% } else { %>
                            <span class="badge bg-danger">Unpaid</span>
                            <td>
<a href="MarkPaidServlet?id=<%= rs.getInt("id") %>" 
class="btn btn-sm btn-success">Mark Paid</a>
</td>
                            <% } %>
                        </td>
                        
                        
                    </tr>
                    <% } %>
                </table>

                <!-- Defaulters Section -->
                <%
                    PreparedStatement defPs = con.prepareStatement(
                            "SELECT COUNT(*) FROM fees WHERE status='Unpaid'"
                    );
                    ResultSet defRs = defPs.executeQuery();
                    defRs.next();

                    PreparedStatement highPs = con.prepareStatement(
                            "SELECT MAX(amount) FROM fees WHERE status='Unpaid'"
                    );
                    ResultSet highRs = highPs.executeQuery();
                    highRs.next();
                %>

                <h4>Defaulters (Unpaid)</h4>
                <h5 style="color:red;">Defaulters: <%= defRs.getInt(1)%></h5>
                <h5>Highest Due: <%= highRs.getDouble(1)%></h5>

            </div>
        </div>
    </body>
</html>
