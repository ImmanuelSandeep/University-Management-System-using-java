<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.Statement"%>
<%@page import="java.sql.Connection"%>
<%
    String role = (String) session.getAttribute("role");
    if (role == null || (!role.equals("admin") && !role.equals("adminstaff"))) {
        response.sendRedirect("accessDenied.jsp");
    }
%>

<!DOCTYPE html>
<html>
    <head>
        <title>Add Faculty</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    </head>
    <%@ include file="navbar.jsp" %>

    <div class="d-flex">
        <%@ include file="sidebar.jsp" %>

        <div style="margin-left:100px; padding:20px; width:100%; height:100vh;">

            <h3>Add Faculty</h3>

            <form action="AddFacultyServlet" method="post">

                <input type="text" name="name" class="form-control mb-2" placeholder="Name" required>

                <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>

                <input type="text" name="phone" class="form-control mb-2" placeholder="Phone" required>

                <select name="department_id" class="form-control mb-2">
                    <%
                        Connection con = dao.DBConnection.getConnection();
                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery("SELECT * FROM departments");

                        while (rs.next()) {
                    %>
                    <option value="<%= rs.getInt("id")%>">
                        <%= rs.getString("name")%>
                    </option>
                    <% }%>
                </select>

                <input type="text" name="subject" class="form-control mb-2" placeholder="Subject" required>

                <input type="number" name="experience" class="form-control mb-2" placeholder="Experience (years)" required>

                <input type="number" name="salary" class="form-control mb-2" placeholder="Salary" required>

                <button class="btn btn-warning">Submit</button>

            </form>

        </div>
    </div>
    <%@ include file="footer.jsp" %>
</body>
</html>