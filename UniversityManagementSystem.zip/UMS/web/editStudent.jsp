<%@ page import="java.sql.*, dao.DBConnection" %>

<%
String role = (String) session.getAttribute("role");
if (role == null || (!"admin".equals(role) && !"adminstaff".equals(role))) {
    response.sendRedirect("accessDenied.jsp");
}

int id = Integer.parseInt(request.getParameter("id"));

Connection con = DBConnection.getConnection();

// GET STUDENT
PreparedStatement ps = con.prepareStatement(
"SELECT * FROM students WHERE id=?"
);
ps.setInt(1, id);
ResultSet rs = ps.executeQuery();
rs.next();

// GET DEPARTMENTS
Statement st = con.createStatement();
ResultSet deptRs = st.executeQuery("SELECT * FROM departments");
%>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>

<%@ include file="navbar.jsp" %>

<div class="d-flex">
<%@ include file="sidebar.jsp" %>

<div style="margin-left:240px; padding:20px; width:100%;">

<h3 class="mb-4">Edit Student</h3>

<div class="card p-4 shadow-sm" style="max-width:600px; border-radius:12px;">

<form action="UpdateStudentServlet" method="post">

<input type="hidden" name="id" value="<%= rs.getInt("id") %>">

<!-- NAME -->
<label>Name</label>
<input type="text" name="name" class="form-control mb-3"
value="<%= rs.getString("name") %>" required>

<!-- EMAIL -->
<label>Email</label>
<input type="email" name="email" class="form-control mb-3"
value="<%= rs.getString("email") %>" required>

<!-- PHONE -->
<label>Phone</label>
<input type="text" name="phone" class="form-control mb-3"
value="<%= rs.getString("phone") %>" required>

<!-- DEPARTMENT -->
<label>Department</label>
<select name="department_id" class="form-control mb-3">

<%
while(deptRs.next()){
%>

<option value="<%= deptRs.getInt("id") %>"
<%= (deptRs.getInt("id") == rs.getInt("department_id")) ? "selected" : "" %>>

<%= deptRs.getString("name") %>

</option>

<%
}
%>

</select>

<!-- YEAR -->
<label>Year</label>
<select name="year" class="form-control mb-3">

<option value="1" <%= rs.getInt("year")==1?"selected":"" %>>1st Year</option>
<option value="2" <%= rs.getInt("year")==2?"selected":"" %>>2nd Year</option>
<option value="3" <%= rs.getInt("year")==3?"selected":"" %>>3rd Year</option>
<option value="4" <%= rs.getInt("year")==4?"selected":"" %>>4th Year</option>

</select>

<button class="btn btn-dark w-100">Update Student</button>

</form>

</div>

</div>
</div>

<%@ include file="footer.jsp" %>

</body>
</html>