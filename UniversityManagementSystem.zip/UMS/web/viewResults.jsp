<%@ page import="java.sql.*, dao.DBConnection" %>
<%@ include file="navbar.jsp" %>
<%
    String role = (String) session.getAttribute("role");
    if (!role.equals("admin") && !role.equals("exam")) {
        response.sendRedirect("accessDenied.jsp");
    }
%>
<!DOCTYPE html>
<html>
    <head>
        <title>View Students</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
        <style>

            .row {
                margin: 0;
            }
            .card {
                height: auto;
            }
            .result-card {
                border-radius: 16px;
                padding: 15px;
                background: #ffffff;
                box-shadow: 0 6px 20px rgba(0,0,0,0.08);
                transition: 0.3s;
            }

            .result-card:hover {
                transform: translateY(-5px);
            }

            .result-title {
                font-weight: 600;
                color: #555;
            }

            .result-value {
                font-size: 18px;
                font-weight: bold;
            }

            .filter-box {
                background: #f8f9fa;
                padding: 15px;
                border-radius: 12px;
                margin-bottom: 15px;
            }

            .topper-card {
                background: linear-gradient(135deg,#6366f1,#8b5cf6);
                color: white;
                border-radius: 16px;
                padding: 20px;
            }
        </style>
    </head>
    <body>
        <div class="d-flex">
            <%@ include file="sidebar.jsp" %>

            <div style="margin-left:100px; padding:20px; width:100%;">

                <h3>Results</h3>

                <%
                    Connection con = DBConnection.getConnection();
                    String dept = request.getParameter("dept");
                    String year = request.getParameter("year");
                    String minCgpa = request.getParameter("minCgpa");
                    String maxCgpa = request.getParameter("maxCgpa");

                    String baseQuery = "SELECT s.name, r.sgpa, r.cgpa, d.name AS dept, s.year "
                            + "FROM results r "
                            + "JOIN students s ON r.student_id=s.id "
                            + "JOIN departments d ON s.department_id=d.id WHERE 1=1";

                    if (dept != null && !dept.equals("")) {
                        baseQuery += " AND d.name='" + dept + "'";
                    }
                    if (year != null && !year.equals("")) {
                        baseQuery += " AND s.year=" + year;
                    }
                    if (minCgpa != null && !minCgpa.equals("")) {
                        baseQuery += " AND r.cgpa >= " + minCgpa;
                    }
                    if (maxCgpa != null && !maxCgpa.equals("")) {
                        baseQuery += " AND r.cgpa <= " + maxCgpa;
                    }

                    // Topper query
                    String topperQuery = baseQuery + " ORDER BY r.cgpa DESC LIMIT 1";
                    PreparedStatement topPs = con.prepareStatement(topperQuery);
                    ResultSet topRs = topPs.executeQuery();
                    String topName = "-";
                    double topCgpa = 0;
                    if (topRs.next()) {
                        topName = topRs.getString("name");
                        topCgpa = topRs.getDouble("cgpa");
                    }

                    // Pass/Fail counts
                    String passQuery = baseQuery + " AND r.cgpa >= 5";
                    String failQuery = baseQuery + " AND r.cgpa < 5";

                    ResultSet passRs = con.createStatement().executeQuery("SELECT COUNT(*) FROM (" + passQuery + ") as t");
                    passRs.next();
                    int passCount = passRs.getInt(1);

                    ResultSet failRs = con.createStatement().executeQuery("SELECT COUNT(*) FROM (" + failQuery + ") as t");
                    failRs.next();
                    int failCount = failRs.getInt(1);

                    // Main student list
                    PreparedStatement ps = con.prepareStatement(baseQuery);
                    ResultSet rs = ps.executeQuery();
                %>

                <form method="get" class="mb-3">
                    <input type="number" step="0.1" name="minCgpa" placeholder="Min CGPA" class="form-control w-25 d-inline">
                    <input type="number" step="0.1" name="maxCgpa" placeholder="Max CGPA" class="form-control w-25 d-inline">
                    <div class="filter-box">

                        <form method="get">

                            <select name="dept" class="form-select w-25 d-inline">
                                <option value="">Department</option>
                                <%
                                    Connection con2 = DBConnection.getConnection();
                                    ResultSet rs2 = con2.createStatement().executeQuery("SELECT * FROM departments");
                                    while (rs2.next()) {
                                %>
                                <option value="<%= rs2.getString("name")%>">
                                    <%= rs2.getString("name")%>
                                </option>
                                <% }%>
                            </select>

                            <select name="year" class="form-select w-25 d-inline">
                                <option value="">Year</option>
                                <option>1</option><option>2</option><option>3</option><option>4</option>
                            </select>

                            <input type="number" name="minCgpa" placeholder="Min CGPA" class="form-control w-25 d-inline">
                            <input type="number" name="maxCgpa" placeholder="Max CGPA" class="form-control w-25 d-inline">

                            <button class="btn btn-dark">Apply</button>

                        </form>

                    </div>

                    <button class="btn btn-primary">Filter</button>
                </form>

                <!-- Topper Card -->
                <div class="card p-3 mb-3 shadow-sm bg-info text-white">
                    <h5>Topper (Filtered)</h5>
                    <h4><%= topName%></h4>
                    <p>CGPA: <%= topCgpa%></p>
                </div>

                <!-- Pass/Fail Cards -->
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="card p-3 shadow-sm bg-success text-white">
                            <h5>Pass</h5>
                            <h3><%= passCount%></h3>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card p-3 shadow-sm bg-danger text-white">
                            <h5>Fail</h5>
                            <h3><%= failCount%></h3>
                        </div>
                    </div>
                </div>

                <!-- Student Cards -->
                <div class="row g-4">

                    <%
                        while (rs.next()) {
                    %>

                    <div class="col-md-4">
                        <div class="card shadow-sm p-3" style="border-radius:12px;">

                            <h5><%= rs.getString("name")%></h5>
                            <p class="text-muted mb-1"><%= rs.getString("dept")%> | Year <%= rs.getInt("year")%></p>

                            <div class="d-flex justify-content-between mt-2">
                                <span>CGPA</span>
                                <strong><%= rs.getDouble("cgpa")%></strong>
                            </div>

                        </div>
                    </div>

                    <%
                        }
                    %>

                </div>

            </div>
        </div>
    </body>
</html>
