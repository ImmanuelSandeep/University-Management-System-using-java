<%@ page import="java.sql.*, dao.DBConnection" %>

<%
    String role = (String) session.getAttribute("role");
    if (role == null || (!"admin".equals(role))) {
        response.sendRedirect("accessDenied.jsp");
    }

    int id = Integer.parseInt(request.getParameter("id"));

    Connection con = DBConnection.getConnection();

// GET FACULTY
    PreparedStatement ps = con.prepareStatement(
            "SELECT * FROM faculty WHERE id=?"
    );
    ps.setInt(1, id);
    ResultSet rs = ps.executeQuery();
    rs.next();

// GET DEPARTMENTS
    Statement st = con.createStatement();
    ResultSet deptRs = st.executeQuery("SELECT * FROM departments");
%>

<!DOCTYPE html>
<html>
    <head>
        <title>Edit Faculty</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    </head>

    <%@ include file="navbar.jsp" %>

    <div class="d-flex">
        <%@ include file="sidebar.jsp" %>

        <div style="margin-left:240px; padding:20px; width:100%;">

            <h3 class="mb-4">Edit Faculty</h3>

            <div class="card p-4 shadow-sm" style="max-width:600px; border-radius:12px;">

                <form action="UpdateFacultyServlet" method="post">

                    <input type="hidden" name="id" value="<%= rs.getInt("id")%>">

                    <!-- NAME -->
                    <label>Name</label>
                    <input type="text" name="name" class="form-control mb-3"
                           value="<%= rs.getString("name")%>" required>

                    <!-- EMAIL -->
                    <label>Email</label>
                    <input type="email" name="email" class="form-control mb-3"
                           value="<%= rs.getString("email")%>" required>

                    <!-- PHONE -->
                    <label>Phone</label>
                    <input type="text" name="phone" class="form-control mb-3"
                           value="<%= rs.getString("phone")%>" required>

                    <!-- SUBJECT -->
                    <label>Subject</label>
                    <input type="text" name="subject" class="form-control mb-3"
                           value="<%= rs.getString("subject")%>" required>

                    <!-- EXPERIENCE -->
                    <label>Experience (Years)</label>
                    <input type="number" name="experience" class="form-control mb-3"
                           value="<%= rs.getInt("experience")%>" required>

                    <!-- SALARY -->
                    <label>Salary</label>
                    <input type="number" name="salary" class="form-control mb-3"
                           value="<%= rs.getInt("salary")%>" required>

                    <!-- DEPARTMENT -->
                    <label>Department</label>
                    <select name="department_id" class="form-control mb-3">

                        <%
                            while (deptRs.next()) {
                        %>

                        <option value="<%= deptRs.getInt("id")%>"
                                <%= (deptRs.getInt("id") == rs.getInt("department_id")) ? "selected" : ""%>>

                            <%= deptRs.getString("name")%>

                        </option>

                        <%
                            }
                        %>

                    </select>

                    <button class="btn btn-dark w-100">Update Faculty</button>

                </form>

            </div>

        </div>
    </div>

    <%@ include file="footer.jsp" %>

</body>
</html>