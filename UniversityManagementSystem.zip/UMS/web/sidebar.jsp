
<style>
.sidebar {
    width: 320px;
    height: auto;
    background: #111827;
    position: relative;
    padding-top: 20px;
   
}

.sidebar a {
    display: block;
    color: #cbd5e1;
    padding: 10px 20px;
    text-decoration: none;
    transition: 0.2s;
     margin: 10px;
     text-align: center;
}

.sidebar a:hover {
    background: #1f2937;
    color: white;
}
</style>

<div class="sidebar">

<a href="dashboard.jsp">Dashboard</a>

<% if("admin".equals(session.getAttribute("role")) || 
      "adminstaff".equals(session.getAttribute("role"))) { %>
<a href="viewStudents.jsp">Students</a>
<% } %>

<% if("admin".equals(session.getAttribute("role"))) { %>
<a href="viewFaculty.jsp">Faculty</a>
<a href="viewSubjects.jsp">Subjects</a>
<a href="addUser.jsp">Add User</a>
<a href="loginActivity.jsp">Login Activity</a>
<% } %>

<% if("admin".equals(session.getAttribute("role")) || 
      "exam".equals(session.getAttribute("role"))) { %>
<a href="viewResults.jsp">Results</a>
<% } %>

<% if("admin".equals(session.getAttribute("role")) || 
      "finance".equals(session.getAttribute("role"))) { %>
<a href="viewFees.jsp">Fees</a>
<% } %>

</div>
