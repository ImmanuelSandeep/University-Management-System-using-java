<%@ page import="java.sql.*, dao.DBConnection" %>

<%
    String role = (String) session.getAttribute("role");
    if (role == null || (!role.equals("admin") && !role.equals("adminstaff"))) {
        response.sendRedirect("accessDenied.jsp");
        return;
    }

    // --- PAGINATION LOGIC ---
    int rowsPerPage = 50;
    int currentPage = 1;
    if (request.getParameter("page") != null) {
        currentPage = Integer.parseInt(request.getParameter("page"));
    }
    int offset = (currentPage - 1) * rowsPerPage;

    String dept = request.getParameter("department");
    Connection con = dao.DBConnection.getConnection();

    // 1. Base Query
    String query = "SELECT f.*, d.name AS dept_name FROM faculty f "
            + "JOIN departments d ON f.department_id = d.id WHERE 1=1";

    if (dept != null && !dept.equals("")) {
        query += " AND d.name='" + dept + "'";
    }

    // 2. Ordering and Pagination
    query += " ORDER BY f.id ASC LIMIT " + rowsPerPage + " OFFSET " + offset;

    PreparedStatement ps = con.prepareStatement(query);
    ResultSet rs = ps.executeQuery();
%>

<!DOCTYPE html>
<html>
    <head>
        <title>View Faculty</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body>
        <%@ include file="navbar.jsp" %>

        <div class="d-flex">
            <%@ include file="sidebar.jsp" %>

            <div style="margin-left:100px; padding:20px; width:100%;">
                <h3>Faculty Management</h3>
                <%
                    String added = request.getParameter("added");
                    String deleted = request.getParameter("deleted");
                    String success = request.getParameter("success");
                    String updated = request.getParameter("updated");
                    String error = request.getParameter("error");
                %>

                <!-- ADD -->
                <% if ("success".equals(added)) { %>
                <div class="alert alert-success alert-dismissible fade show">
                    Faculty added successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <% } else if ("fail".equals(added)) { %>
                <div class="alert alert-danger">Failed to add faculty!</div>
                <% } %>

                <!-- DELETE -->
                <% if ("success".equals(deleted)) { %>
                <div class="alert alert-success alert-dismissible fade show">
                    Faculty deleted successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <% } else if ("fail".equals(deleted)) { %>
                <div class="alert alert-danger">Failed to delete faculty!</div>
                <% } %>

                <!-- UPDATE -->
                <% if ("success".equals(updated)) { %>
                <div class="alert alert-success alert-dismissible fade show">
                    Faculty updated successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <% } else if ("fail".equals(updated)) { %>
                <div class="alert alert-danger alert-dismissible fade show">
                    Failed to update faculty!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <% } %>

                <!-- ERROR -->
                <% if ("failed".equals(error)) { %>
                <div class="alert alert-danger">
                    Operation failed. Try again.
                </div>
                <% } %>


                <form method="get" class="mb-3 d-flex align-items-center">
                    <select name="department" class="form-select w-25 me-2">
                        <option value="">All Departments</option>
                        <%
                            Connection conDept = dao.DBConnection.getConnection();
                            ResultSet rsDept = conDept.createStatement().executeQuery("SELECT * FROM departments");
                            while (rsDept.next()) {
                                String dName = rsDept.getString("name");
                        %>
                        <option value="<%= dName%>" <%= (dName.equals(dept)) ? "selected" : ""%>>
                            <%= dName%>
                        </option>
                        <% } %>
                    </select>
                    <button class="btn btn-primary me-2">Filter</button>

                    <div class="ms-auto" id="btnContainer">
                        <a href="addFaculty.jsp" id="addBtn" class="btn btn-success">Add Faculty</a>
                        <button type="button" id="bulkDeleteBtn" class="btn btn-danger" style="display:none;" onclick="submitBulkDelete()">
                            Delete Selected (<span id="count">0</span>)
                        </button>
                    </div>
                </form>
                <%
                    if ("updated".equals(success)) {
                %>

                <div class="alert alert-success alert-dismissible fade show">
                    Faculty updated successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>

                <%
                    }
                %>
                <form id="bulkDeleteForm" action="BulkDeleteFacultyServlet" method="post">
                    <table class="table table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th><input type="checkbox" id="selectAll"></th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Department</th>
                                <th>Subject</th>
                                <th>Experience</th>
                                <th>Salary</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% while (rs.next()) {%>
                            <tr>
                                <td><input type="checkbox" name="facultyIds" value="<%= rs.getInt("id")%>" class="faculty-checkbox"></td>
                                <td><%= rs.getString("name")%></td>
                                <td><%= rs.getString("email")%></td>
                                <td><%= rs.getString("phone")%></td>
                                <td><%= rs.getString("dept_name")%></td>
                                <td><%= rs.getString("subject")%></td>
                                <td><%= rs.getInt("experience")%> yrs</td>
                                <td><%= rs.getDouble("salary")%></td>
                                <td>
                                    <a href="editFaculty.jsp?id=<%= rs.getInt("id")%>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="DeleteFacultyServlet?id=<%= rs.getInt("id")%>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this faculty?')">Delete</a>
                                </td>
                            </tr>
                            <% }%>
                        </tbody>
                    </table>
                </form>

                <nav>
                    <ul class="pagination justify-content-center">
                        <li class="page-item <%= (currentPage == 1) ? "disabled" : ""%>">
                            <a class="page-link" href="?page=<%= currentPage - 1%>&department=<%= (dept != null) ? dept : ""%>">Previous</a>
                        </li>
                        <li class="page-item disabled"><span class="page-link text-dark">Page <%= currentPage%></span></li>
                        <li class="page-item">
                            <a class="page-link" href="?page=<%= currentPage + 1%>&department=<%= (dept != null) ? dept : ""%>">Next</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>

        <%@ include file="footer.jsp" %>

        <%@ include file="footer.jsp" %>

        <script type="text/javascript">
            // This needs to be globally accessible for the button onclick
            function submitBulkDelete() {
                if (confirm("Are you sure you want to delete all selected faculty?")) {
                    document.getElementById('bulkDeleteForm').submit();
                }
            }

            document.addEventListener("DOMContentLoaded", function () {
                const selectAll = document.getElementById('selectAll');
                const checkboxes = document.querySelectorAll('.faculty-checkbox');
                const addBtn = document.getElementById('addBtn');
                const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
                const countSpan = document.getElementById('count');

                // FUNCTION TO SWAP BUTTONS
                function updateUI() {
                    const checkedCount = document.querySelectorAll('.faculty-checkbox:checked').length;
                    if (checkedCount > 0) {
                        addBtn.style.display = 'none';
                        bulkDeleteBtn.style.display = 'block';
                        countSpan.textContent = checkedCount;
                    } else {
                        addBtn.style.display = 'block';
                        bulkDeleteBtn.style.display = 'none';
                    }
                }

                // INDIVIDUAL CHECKBOX LISTENER
                checkboxes.forEach(cb => {
                    cb.addEventListener('change', updateUI);
                });

                // SELECT ALL LISTENER
                if (selectAll) {
                    selectAll.addEventListener('change', function () {
                        checkboxes.forEach(cb => cb.checked = this.checked);
                        updateUI();
                    });
                }

                // Auto-hide alerts after 3 seconds
                setTimeout(() => {
                    document.querySelectorAll('.alert').forEach(a => {
                        // Use Bootstrap's fade class logic or just remove
                        a.classList.remove('show');
                        setTimeout(() => a.remove(), 150);
                    });
                }, 3000);
            }); // End of DOMContentLoaded
        </script>


    </body>
</html>