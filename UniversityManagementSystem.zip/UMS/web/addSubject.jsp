<%@ page import="java.sql.*, dao.DBConnection" %>
<%
    String role = (String) session.getAttribute("role");

    if (role == null || (!"admin".equals(role) && !"adminstaff".equals(role))) {
        response.sendRedirect("accessDenied.jsp");
    }
%>
<%@ include file="navbar.jsp" %>

<div class="d-flex">
    <%@ include file="sidebar.jsp" %>

    <div style="margin-left:240px; padding:20px; width:100%;">

        <h3>Add Subject</h3>

        <form action="AddSubjectServlet" method="post">

            <input type="text" name="name" class="form-control mb-2" placeholder="Subject Name" required>

            <!-- DEPARTMENT -->
            <select name="department_id" class="form-control mb-2">
                <%
                    Connection con = DBConnection.getConnection();
                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery("SELECT * FROM departments");

                    while (rs.next()) {
                %>
                <option value="<%= rs.getInt("id")%>">
                    <%= rs.getString("name")%>
                </option>
                <% }%>
            </select>

            <input type="number" name="credits" class="form-control mb-2" placeholder="Credits" required>

            <button class="btn btn-dark">Submit</button>

        </form>

    </div>
</div>
<%@ include file="footer.jsp" %>