<%@page import="dao.DBConnection"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.Connection"%>
<%@ include file="navbar.jsp" %>

<div class="d-flex">
<%@ include file="sidebar.jsp" %>

<div class="content p-4" style="width:100%;">

<h3 class="mb-4">Login Activity</h3>

<div class="card shadow-sm p-3">

<table class="table table-hover">
<thead class="table-light">
<tr>
<th>User</th>
<th>Role</th>
<th>Login Time</th>
</tr>
</thead>

<tbody>
<%
Connection con = DBConnection.getConnection();
ResultSet rs = con.createStatement().executeQuery(
"SELECT * FROM login_logs ORDER BY login_time DESC");

while(rs.next()){
%>

<tr>
<td><%= rs.getString("username") %></td>
<td><%= rs.getString("role") %></td>
<td><%= rs.getTimestamp("login_time") %></td>
</tr>

<% } %>
</tbody>

</table>

</div>
</div>
</div>