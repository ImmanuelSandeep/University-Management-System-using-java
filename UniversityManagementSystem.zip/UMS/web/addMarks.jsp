<%@ page import="java.sql.*, dao.DBConnection" %>
<%
    String role = (String) session.getAttribute("role");
    if (!role.equals("admin") && !role.equals("exam")) {
        response.sendRedirect("accessDenied.jsp");
    }
%>
<%@ include file="navbar.jsp" %>
<!DOCTYPE html>
<html>
    <head>
        <title>Add Faculty</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    </head>
    <div class="d-flex">
        <%@ include file="sidebar.jsp" %>

        <div style="margin-left:240px; padding:20px; width:100%;">

            <h3>Add Marks</h3>

            <form action="AddMarksServlet" method="post">

                <!-- STUDENT -->
                <select name="student_id" class="form-control mb-2">
                    <%
                        Connection con = DBConnection.getConnection();
                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery("SELECT * FROM students");

                        while (rs.next()) {
                    %>
                    <option value="<%= rs.getInt("id")%>">
                        <%= rs.getString("name")%>
                    </option>
                    <% } %>
                </select>

                <!-- SUBJECT -->
                <select name="subject_id" class="form-control mb-2">
                    <%
                        ResultSet rs2 = st.executeQuery("SELECT * FROM subjects");
                        while (rs2.next()) {
                    %>
                    <option value="<%= rs2.getInt("id")%>">
                        <%= rs2.getString("name")%>
                    </option>
                    <% }%>
                </select>

                <input type="number" name="class_test" placeholder="Class Test" class="form-control mb-2">
                <input type="number" name="sessional" placeholder="Sessional" class="form-control mb-2">
                <input type="number" name="final_exam" placeholder="Final Exam" class="form-control mb-2">

                <button class="btn btn-success">Submit</button>

            </form>

        </div>
    </div>
    <%@ include file="footer.jsp" %>
</body>
</html>