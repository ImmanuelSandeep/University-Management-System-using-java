<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.Statement"%>
<%@page import="java.sql.Connection"%>
<%
    String role = (String) session.getAttribute("role");
    if (!role.equals("admin") && !role.equals("adminstaff")) {
        response.sendRedirect("accessDenied.jsp");
    }
%>
<!DOCTYPE html>
<html>
    <head>
        <title>Add Student</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    </head>
    <%@ include file="navbar.jsp" %>

    <div class="d-flex">
        <%@ include file="sidebar.jsp" %>

        <div style="margin-left:100px; padding:20px; width:100%; height:100vh;">

            <h3>Add Student</h3>
            <%
                String error = request.getParameter("error");

                if ("duplicate".equals(error)) {
            %>

            <div class="alert alert-danger">
                Roll Number already exists!
            </div>

            <%
                }
            %>
            <form action="AddStudentServlet" method="post">

                <input type="text" name="rollno" class="form-control mb-2" placeholder="Roll Number" required>
                <input type="text" name="name" class="form-control mb-2" placeholder="Name" required>
                <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>
                <input type="text" name="phone" class="form-control mb-2" placeholder="Phone" required>

                <!-- DEPARTMENT DROPDOWN -->
                <select name="department_id" class="form-control mb-2">
                    <%
                        Connection con = dao.DBConnection.getConnection();
                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery("SELECT * FROM departments");

                        while (rs.next()) {
                    %>
                    <option value="<%= rs.getInt("id")%>">
                        <%= rs.getString("name")%>
                    </option>
                    <% }%>
                </select>

                <!-- YEAR -->
                <select name="year" class="form-control mb-2">
                    <option value="1">1st Year</option>
                    <option value="2">2nd Year</option>
                    <option value="3">3rd Year</option>
                    <option value="4">4th Year</option>
                </select>

                <button class="btn btn-primary">Submit</button>

            </form>
        </div>
    </div>
    <%@ include file="footer.jsp" %>
</body>
<script>
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('added') === 'fail') {
        alert("Failed to add student. Please check the details and try again.");

        // Clean the URL
        window.history.replaceState({}, document.title, window.location.pathname);
    }
</script>
</html>