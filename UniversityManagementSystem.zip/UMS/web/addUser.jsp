<%@ include file="navbar.jsp" %>

<div class="d-flex">
    <%@ include file="sidebar.jsp" %>

    <div class="content p-4" style="width:100%;">

        <h3 class="mb-4">Add New User</h3>

        <div class="card shadow-sm p-4" style="max-width:500px; border-radius:12px;">

            <form action="AddUserServlet" method="post">

                <div class="mb-3">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Role</label>
                    <select name="role" class="form-control">
                        <option value="admin">Admin</option>
                        <option value="finance">Finance</option>
                        <option value="exam">Exam</option>
                        <option value="adminstaff">Admin Staff</option>
                    </select>
                </div>

                <button class="btn btn-dark w-100">Create User</button>

            </form>

        </div>
    </div>
</div>
<%@ include file="footer.jsp" %>