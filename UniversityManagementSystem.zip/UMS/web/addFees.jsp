<%@ page import="java.sql.*, dao.DBConnection" %>
<%
    String role = (String) session.getAttribute("role");
    if (!role.equals("admin") && !role.equals("finance")) {
        response.sendRedirect("accessDenied.jsp");
    }
%>
<%@ include file="navbar.jsp" %>
<!DOCTYPE html>
<html>
    <head>
        <title>Add Faculty</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    </head>
    <div class="d-flex">
        <%@ include file="sidebar.jsp" %>

        <div style="margin-left:240px; padding:20px; width:100%;">

            <h3>Add Fees</h3>

            <form action="AddFeesServlet" method="post">

                <!-- STUDENT (SHOW DEPT + YEAR) -->
                <select name="student_id" class="form-control mb-2">
                    <%
                        Connection con = DBConnection.getConnection();
                        Statement st = con.createStatement();

                        ResultSet rs = st.executeQuery(
                                "SELECT s.id, s.name, s.year, d.name AS dept FROM students s "
                                + "JOIN departments d ON s.department_id=d.id"
                        while (rs.next()) {
                    %>
                    <option value="<%= rs.getInt("id")%>">
                        <%= rs.getString("name")%> 
                        - <%= rs.getString("dept")%> 
                        (Year <%= rs.getInt("year")%>)
                    </option>
                    <% }%>
                </select>

                <input type="number" name="amount" class="form-control mb-2" placeholder="Amount" required>

                <!-- SEMESTER -->
                <select name="semester" class="form-control mb-2">
                    <option value="1">Semester 1</option>
                    <option value="2">Semester 2</option>
                    <option value="3">Semester 3</option>
                    <option value="4">Semester 4</option>
                    <option value="5">Semester 5</option>
                    <option value="6">Semester 6</option>
                    <option value="7">Semester 7</option>
                    <option value="8">Semester 8</option>
                </select>

                <select name="status" class="form-control mb-2">
                    <option value="Paid">Paid</option>
                    <option value="Unpaid">Unpaid</option>
                </select>

                <button class="btn btn-success">Submit</button>

            </form>

        </div>
    </div>
    <%@ include file="footer.jsp" %>
</body>
</html>