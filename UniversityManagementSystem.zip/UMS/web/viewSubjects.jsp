<%@ page import="java.sql.*, dao.DBConnection" %>
<%
    String role = (String) session.getAttribute("role");
    if (role == null || (!role.equals("admin") && !role.equals("adminstaff"))) {
        response.sendRedirect("accessDenied.jsp");
        return;
    }

    // --- PAGINATION LOGIC ---
    int rowsPerPage = 10;
    int currentPage = 1;
    if (request.getParameter("page") != null) {
        currentPage = Integer.parseInt(request.getParameter("page"));
    }
    int offset = (currentPage - 1) * rowsPerPage;

    String Branch = request.getParameter("Branch");
    Connection con = DBConnection.getConnection();

    // 1. Base Query
    String query = "SELECT s.*, d.name AS dept_name FROM subjects s "
                 + "JOIN departments d ON s.department_id = d.id WHERE 1=1";

    if (Branch != null && !Branch.equals("")) {
        query += " AND d.name=?";
    }

    // 2. Add Ordering and Pagination
    query += " ORDER BY s.id ASC LIMIT " + rowsPerPage + " OFFSET " + offset;

    PreparedStatement ps = con.prepareStatement(query);
    if (Branch != null && !Branch.equals("")) {
        ps.setString(1, Branch);
    }
    ResultSet rs = ps.executeQuery();

    // Catch Alert Parameters
    String added = request.getParameter("added");
    String deleted = request.getParameter("deleted");
    String updated = request.getParameter("updated");
%>

<!DOCTYPE html>
<html>
    <head>
        <title>View Subjects</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </head> 
    <body>
    <%@ include file="navbar.jsp" %>

    <div class="d-flex">
        <%@ include file="sidebar.jsp" %>

        <div style="margin-left:100px; padding:20px; width:100%;">

            <h3>Subjects Management</h3>

            <% if ("success".equals(added)) { %>
                <div class="alert alert-success alert-dismissible fade show">
                    Subject added successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <% } %>
            <% if ("success".equals(deleted)) { %>
                <div class="alert alert-danger alert-dismissible fade show">
                    Subject deleted successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <% } %>
            <% if ("success".equals(updated)) { %>
                <div class="alert alert-info alert-dismissible fade show">
                    Subject updated successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <% } %>

            <form method="get" class="mb-3 d-flex align-items-center">
                <select name="Branch" class="form-select w-25 me-2">
                    <option value="">All Departments</option>
                    <option value="CSE" <%= "CSE".equals(Branch) ? "selected" : "" %>>CSE</option>
                    <option value="IT" <%= "IT".equals(Branch) ? "selected" : "" %>>IT</option>
                    <option value="ECE" <%= "ECE".equals(Branch) ? "selected" : "" %>>ECE</option>
                    <option value="EIE" <%= "EIE".equals(Branch) ? "selected" : "" %>>EIE</option>
                    <option value="ME" <%= "ME".equals(Branch) ? "selected" : "" %>>ME</option>
                    <option value="CE" <%= "CE".equals(Branch) ? "selected" : "" %>>CE</option>
                </select>

                <button class="btn btn-primary me-2">Filter</button>

                <div class="ms-auto">
                    <a href="addSubject.jsp" class="btn btn-success">Add Subject</a>
                </div>
            </form>

            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Subject Name</th>
                        <th>Department</th>
                        <th>Credits</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <% while (rs.next()) { %>
                    <tr>
                        <td><%= rs.getInt("id")%></td>
                        <td><%= rs.getString("name")%></td>
                        <td><%= rs.getString("dept_name")%></td>
                        <td><%= rs.getInt("credits")%></td>
                        <td>
                            <a href="editSubject.jsp?id=<%= rs.getInt("id")%>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="DeleteSubjectServlet?id=<%= rs.getInt("id")%>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this subject?')">Delete</a>
                        </td>
                    </tr>
                    <% } %>
                </tbody>
            </table>

            <nav>
                <ul class="pagination justify-content-center">
                    <li class="page-item <%= (currentPage == 1) ? "disabled" : "" %>">
                        <a class="page-link" href="?page=<%= currentPage - 1 %>&Branch=<%= (Branch != null) ? Branch : "" %>">Previous</a>
                    </li>
                    <li class="page-item disabled">
                        <span class="page-link text-dark">Page <strong><%= currentPage %></strong></span>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?page=<%= currentPage + 1 %>&Branch=<%= (Branch != null) ? Branch : "" %>">Next</a>
                    </li>
                </ul>
            </nav>

        </div>
    </div>
    <%@ include file="footer.jsp" %>

    <script>
        // Auto-hide alerts after 3 seconds
        setTimeout(() => {
            document.querySelectorAll('.alert').forEach(a => {
                const bsAlert = new bootstrap.Alert(a);
                bsAlert.close();
            });
        }, 3000);

        // Clean the URL parameters
        if (window.location.search.includes('added') || window.location.search.includes('deleted') || window.location.search.includes('updated')) {
            const cleanUrl = window.location.pathname + (window.location.search.includes('Branch') ? '?Branch=' + new URLSearchParams(window.location.search).get('Branch') : '');
            window.history.replaceState({}, document.title, cleanUrl);
        }
    </script>
    </body>
</html>