<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
  height: 100vh;
  display: flex;
  flex-direction: column;
}

main {
  flex: 1; /* pushes footer down */
}

footer {
  background: #f8f9fa;
  text-align: center;
  padding: 10px;
}

    </style>
</head>
<body class="bg-dark d-flex flex-column min-vh-100">

  <!-- Main content -->
  <main class="flex-grow-1 d-flex justify-content-center align-items-center bg-dark">
    <div class="bg-white p-4 rounded shadow" style="width: 400px;">
      <h3 class="text-center">Login</h3>

      <form action="LoginServlet" method="post">
        <input type="text" name="username" class="form-control mb-3" placeholder="Username" required>
        <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
        <button class="btn btn-primary w-100">Login</button>
      </form>

      <% if(request.getParameter("error") != null) { %>
        <p class="text-danger mt-2">Invalid credentials</p>
      <% } %>
    </div>
  </main>


</body>

<%@ include file="footer.jsp" %>
</html>